#This program computs the convex hull using a brute force algorithm
#It takes an array of coordinates as input
#It returns a list of coordinates that form the boundary of the convex hull


def convexHull(x):
    #an array that contains a list of points
    coords = x#,,,,(4,5),(7,2)
    #print(coords[0][0]) #this prints the x-coordinate
    boundary = []
    #Values for x and y in the equation
    x = 0
    y = 0
    #for checking the first point to be joined with the others
    for i in range(0,len(coords)):
        #getting the first point
        x1,y1 = coords[i]
        x1y1 = coords[i]
        
       
        #for checking the second point to mak a segment
        for j in range(i+1,len(coords)):
             #getting the second point
            x2,y2 = coords[j]
            x2y2 = coords[j]
            #calculating the line segment
            a = y2 - y1
            b = x1 - x2
            c = x1*y2 - y1*x2
            
            #checking the side to the segment, that other points are on
            for k in range(0,len(coords)):

                
                seg_check = coords[k]
                x= seg_check[0]
                y= seg_check[1]
                sign_check = a*x + b*y - c
                
                positive = []
                negative = []
                #populate the positive list
                if sign_check>0:
                    positive.append(1)
                            #populate the negative list
                elif sign_check<0:
                    negative.append(0) 
                
                
                #if seg_check != coords[i] & seg_check != coords[j]:
                if seg_check!= x1y1:
                    if seg_check!= x2y2 :#seg_check[0]!=coords[i][0] & seg_check[1] !=coords[i][1] & seg_check[0] !=coords[j][0]& seg_check[1] !=coords[j][1]:                   
                        #determining side to determine sign
                     
                
                        #print("Sign check: ",sign_check)
                        if len(positive)==0:# | len(negative)==0:
                            #add points to convex hull
                            boundary.append(coords[i])
                            boundary.append(coords[j]) 
    print("Convex Hull: ",boundary)  
           
convexHull([(-1,0),(1,0),(2,3),(2,-3)])
        
