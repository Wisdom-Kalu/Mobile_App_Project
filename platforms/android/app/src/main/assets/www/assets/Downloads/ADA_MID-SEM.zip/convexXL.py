import pandas as pd
def convexHullXL():
    option = eval(input("Enter 1 for Ghana and 2 for South Africa"))
    
    if(option==1):
        df = pd.read_excel('C:/Users/lwamp/OneDrive - Ashesi University/Year_Three/Spring Semester-2020/Algorithm Design & Analysis/CityLatLong.xlsx', sheet_name=0,skiprows=1) # can also index sheet by name or fetch all sheets
        xlist = df['x-coordinate'].tolist()
        ylist = df['y-coordinate'].tolist()
         #an array that contains a list of points
        coords = tuple(zip(xlist, ylist))
       
   
        #print(coords[0][0]) #this prints the x-coordinate
        boundary = []
        positive = []
        negative = []

        #Values for x and y in the equation
        x = 0
        y = 0
        #for checking the first point to be joined with the others
        for i in range(0,len(coords)-1):
        #print("lwazi")
        #print(len(coords))
        #print(coords[i])

        #for checking the second point to mak a segment
            for j in range(i+1,len(coords)):
                #getting the first point
                x1,y1 = coords[i]
                x1y1 = coords[i]

                #getting the second point
                x2,y2 = coords[j]
                x2y2 = coords[j]

                #calculating the line segment
                a = y2 - y1
                b = x1 - x2
                c = x1*y2 - y1*x2
                #line segment
                #c= a*x + b*y


                #checking the side to the segment, that other points are on
                for k in range(len(coords)):
                    seg_check = coords[k]
                
                
                    #if seg_check != coords[i] & seg_check != coords[j]:
                    if seg_check!= x1y1:
                        if seg_check!= x2y2 :#seg_check[0]!=coords[i][0] & seg_check[1] !=coords[i][1] & seg_check[0] !=coords[j][0]& seg_check[1] !=coords[j][1]:                   
                            #determining side to determine sign
                            x= seg_check[0]
                            y= seg_check[1]
                            sign_check = a*x + b*y - c

                            #populate the positive list
                            if sign_check>0:
                                positive.append(1)
                                #populate the negative list
                            elif sign_check<0:
                                negative.append(0) 
                    if len(positive)==0 | len(negative)==0:
                                #add points to convex hull
                                boundary.append(coords[i])
                                boundary.append(coords[j]) 
                     
                                
        print("convex hull: ",boundary)  
    else:
        df = pd.read_excel('C:/Users/lwamp/OneDrive - Ashesi University/Year_Three/Spring Semester-2020/Algorithm Design & Analysis/CityLatLong.xlsx', sheet_name=1,skiprows=1) # can also index sheet by name or fetch all sheets
        xlist = df['x-coordinate'].tolist()
        ylist = df['y-coordinate'].tolist()
         #an array that contains a list of points
        coords = tuple(zip(xlist, ylist))
       
   
        #print(coords[0][0]) #this prints the x-coordinate
        boundary = []
        positive = []
        negative = []

        #Values for x and y in the equation
        x = 0
        y = 0
        #for checking the first point to be joined with the others
        for i in range(0,len(coords)-1):

        #for checking the second point to mak a segment
            for j in range(i+1,len(coords)):
                #getting the first point
                x1,y1 = coords[i]
                x1y1 = coords[i]

                #getting the second point
                x2,y2 = coords[j]
                x2y2 = coords[j]

                #calculating the line segment
                a = y2 - y1
                b = x1 - x2
                c = x1*y2 - y1*x2

                #checking the side to the segment, that other points are on
                for k in range(len(coords)):
                    seg_check = coords[k]
                
                    #if seg_check != coords[i] & seg_check != coords[j]:
                    if seg_check!= x1y1:
                        if seg_check!= x2y2 :#seg_check[0]!=coords[i][0] & seg_check[1] !=coords[i][1] & seg_check[0] !=coords[j][0]& seg_check[1] !=coords[j][1]:                   
                            #determining side to determine sign
                            x= seg_check[0]
                            y= seg_check[1]
                            sign_check = a*x + b*y - c

                            #populate the positive list
                            if sign_check>0:
                                positive.append(1)
                                #populate the negative list
                            elif sign_check<0:
                                negative.append(0) 
                    if len(positive)==0 | len(negative)==0:
                                #add points to convex hull
                                boundary.append(coords[i])
                                boundary.append(coords[j]) 
                    else:
                                print("Not a match",-1) 
                print("convex hull: ",boundary)

            
convexHullXL()

